import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../../core/theme/app_theme_tokens.dart';
import '../../../../../injection_container.dart';
import '../bloc/supplier_dashboard/supplier_dashboard_bloc.dart';
import '../bloc/supplier_dashboard/supplier_dashboard_event.dart';
import '../bloc/supplier_dashboard/supplier_dashboard_state.dart';
import '../../../shared/widgets/supplier_app_drawer.dart';
import '../../../shared/widgets/supplier_dashboard_stat_card.dart';
import '../../../shared/widgets/supplier_quick_action_card.dart';

class SupplierDashboardScreen extends StatelessWidget {
  const SupplierDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<SupplierDashboardBloc>(
      create: (_) => sl<SupplierDashboardBloc>()
        ..add(const SupplierDashboardStarted()),
      child: const _SupplierDashboardView(),
    );
  }
}

class _SupplierDashboardView extends StatelessWidget {
  const _SupplierDashboardView();

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;

    return BlocListener<SupplierDashboardBloc, SupplierDashboardState>(
      listenWhen: (previous, current) {
        return previous.errorMessage != current.errorMessage &&
            current.errorMessage != null;
      },
      listener: (context, state) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(state.errorMessage!)),
        );
      },
      child: Scaffold(
        backgroundColor: AppThemeTokens.background,
        drawer: const SupplierAppDrawer(),
        appBar: AppBar(
          backgroundColor: AppThemeTokens.background,
          elevation: 0,
          centerTitle: true,
          leading: Builder(
            builder: (context) {
              return IconButton(
                icon: const Icon(Icons.menu, size: 32),
                onPressed: () => Scaffold.of(context).openDrawer(),
              );
            },
          ),
          title: Text(
            'Supplier Dashboard',
            style: TextStyle(
              color: primary,
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
          actions: [
            IconButton(
              onPressed: () {
                context.read<SupplierDashboardBloc>().add(
                      const SupplierDashboardRefreshed(),
                    );
              },
              icon: const Icon(Icons.refresh_outlined, size: 27),
            ),
            IconButton(
              onPressed: () => context.go('/supplier-settings'),
              icon: const Icon(Icons.settings_outlined, size: 27),
            ),
            const SizedBox(width: 8),
          ],
        ),
        body: BlocBuilder<SupplierDashboardBloc, SupplierDashboardState>(
          builder: (context, state) {
            return SafeArea(
              child: RefreshIndicator(
                onRefresh: () async {
                  context.read<SupplierDashboardBloc>().add(
                        const SupplierDashboardRefreshed(),
                      );
                },
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(
                    AppThemeTokens.screenHorizontalPadding,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (state.isLoading)
                        const _DashboardLoadingCard()
                      else
                        _buildStatsGrid(state),
                      const SizedBox(height: 24),
                      _buildFinancialSummary(context, state),
                      const SizedBox(height: 24),
                      const Text(
                        'Low Stock Alerts',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: AppThemeTokens.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      _buildLowStockAlerts(),
                      const SizedBox(height: 28),
                      const Text(
                        'Quick Actions',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: AppThemeTokens.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 16),
                      _buildQuickActions(context),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildStatsGrid(SupplierDashboardState state) {
    final cards = [
      SupplierDashboardStatCard(
        title: 'Pending Orders',
        value: state.pendingOrders.toString(),
        icon: Icons.receipt_long_outlined,
        iconColor: const Color(0xFFF97316),
        iconBackgroundColor: const Color(0xFFFFEDD5),
      ),
      SupplierDashboardStatCard(
        title: 'Active Orders',
        value: state.activeOrders.toString(),
        icon: Icons.inventory_2_outlined,
        iconColor: const Color(0xFF2563EB),
        iconBackgroundColor: const Color(0xFFDBEAFE),
      ),
      SupplierDashboardStatCard(
        title: 'Shipped Orders',
        value: state.shippedOrders.toString(),
        icon: Icons.local_shipping_outlined,
        iconColor: const Color(0xFFA855F7),
        iconBackgroundColor: const Color(0xFFF3E8FF),
      ),
      SupplierDashboardStatCard(
        title: 'Completed Orders',
        value: state.completedOrders.toString(),
        icon: Icons.check_circle_outline,
        iconColor: const Color(0xFF16A34A),
        iconBackgroundColor: const Color(0xFFDCFCE7),
      ),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: cards.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 0.95,
      ),
      itemBuilder: (context, index) => cards[index],
    );
  }

  Widget _buildFinancialSummary(
    BuildContext context,
    SupplierDashboardState state,
  ) {
    final primary = Theme.of(context).colorScheme.primary;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppThemeTokens.surface,
        borderRadius: BorderRadius.circular(AppThemeTokens.radiusLarge),
        border: Border.all(color: AppThemeTokens.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Financial Summary',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w900,
              color: AppThemeTokens.textPrimary,
            ),
          ),
          const SizedBox(height: 22),
          Row(
            children: [
              Expanded(
                child: _FinancialItem(
                  value: _formatMoney(state.deliveredSales),
                  label: 'Delivered Sales',
                  valueColor: primary,
                ),
              ),
              Expanded(
                child: _FinancialItem(
                  value: _formatMoney(state.monthlyRevenue),
                  label: 'Monthly Revenue',
                  valueColor: primary,
                ),
              ),
              Expanded(
                child: _FinancialItem(
                  value: state.totalOrdersToday.toString(),
                  label: 'Orders Today',
                  valueColor: primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLowStockAlerts() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppThemeTokens.surface,
        borderRadius: BorderRadius.circular(AppThemeTokens.radiusLarge),
        border: Border.all(color: AppThemeTokens.border),
      ),
      child: const Center(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 18),
          child: Text(
            'No low stock alerts',
            style: TextStyle(
              fontSize: 16,
              color: AppThemeTokens.textSecondary,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    final actions = [
      SupplierQuickActionCard(
        title: 'Add Product',
        icon: Icons.add,
        onTap: () => context.push('/supplier-products/add'),
      ),
      SupplierQuickActionCard(
        title: 'Manage Orders',
        icon: Icons.receipt_long_outlined,
        onTap: () => context.go('/supplier-orders'),
      ),
      SupplierQuickActionCard(
        title: 'Manage Branches',
        icon: Icons.location_on_outlined,
        onTap: () => context.go('/supplier-branches'),
      ),
      SupplierQuickActionCard(
        title: 'Create Promotion',
        icon: Icons.local_offer_outlined,
        onTap: () => context.go('/supplier-promotions/create'),
      ),
      SupplierQuickActionCard(
        title: 'Shipping Methods',
        icon: Icons.local_shipping_outlined,
        onTap: () => context.go('/supplier-shipping'),
      ),
      SupplierQuickActionCard(
        title: 'Configure Taxes',
        icon: Icons.attach_money,
        onTap: () => context.go('/supplier-tax'),
      ),
      SupplierQuickActionCard(
        title: 'Home Banners',
        icon: Icons.image_outlined,
        onTap: () => context.go('/supplier-banners/create'),
      ),
      SupplierQuickActionCard(
        title: 'Coupons',
        icon: Icons.sell_outlined,
        onTap: () => context.go('/supplier-coupons/create'),
      ),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: actions.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 1.05,
      ),
      itemBuilder: (context, index) => actions[index],
    );
  }

  String _formatMoney(double amount) {
    return '\$${amount.toStringAsFixed(2)}';
  }
}

class _DashboardLoadingCard extends StatelessWidget {
  const _DashboardLoadingCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: AppThemeTokens.surface,
        borderRadius: BorderRadius.circular(AppThemeTokens.radiusLarge),
        border: Border.all(color: AppThemeTokens.border),
      ),
      child: const Center(
        child: Column(
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 14),
            Text(
              'Loading dashboard data...',
              style: TextStyle(
                color: AppThemeTokens.textSecondary,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FinancialItem extends StatelessWidget {
  final String value;
  final String label;
  final Color valueColor;

  const _FinancialItem({
    required this.value,
    required this.label,
    required this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: valueColor,
            fontSize: 22,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: AppThemeTokens.textSecondary,
            fontSize: 13,
            height: 1.25,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}